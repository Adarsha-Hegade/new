import { supabase } from '../supabase';
import { toast } from 'react-hot-toast';

export async function signIn(email: string, password: string) {
  try {
    // First verify the user exists
    const { data: userExists } = await supabase
      .from('users')
      .select('id')
      .eq('email', email)
      .single();

    if (!userExists) {
      throw new Error('No account found with this email');
    }

    // Attempt to sign in
    const { data, error } = await supabase.auth.signInWithPassword({
      email,
      password
    });

    if (error) throw error;

    // Get complete user profile
    const { data: profile, error: profileError } = await supabase
      .from('users')
      .select('*')
      .eq('id', data.user.id)
      .single();

    if (profileError) throw profileError;

    return {
      user: { ...data.user, ...profile },
      session: data.session
    };
  } catch (error: any) {
    console.error('Sign in error:', error);
    toast.error(error.message || 'Invalid email or password');
    throw error;
  }
}