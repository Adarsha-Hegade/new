import { supabase } from './supabase';
import { PostgrestError } from '@supabase/supabase-js';

export class DatabaseError extends Error {
  constructor(
    message: string,
    public originalError?: PostgrestError | Error
  ) {
    super(message);
    this.name = 'DatabaseError';
  }
}

export const database = {
  async checkAdminExists(): Promise<boolean> {
    try {
      const { data, error } = await supabase
        .rpc('admin_exists');

      if (error) throw new DatabaseError('Failed to check admin status', error);
      return data || false;
    } catch (error) {
      console.error('Database error:', error);
      throw error;
    }
  },

  async createUser(userData: {
    id: string;
    email: string;
    username: string;
    name: string;
    phone_number: string;
    role: 'admin' | 'user';
  }) {
    try {
      const { data, error } = await supabase
        .from('users')
        .insert([userData])
        .select()
        .single();

      if (error) throw new DatabaseError('Failed to create user', error);
      return data;
    } catch (error) {
      console.error('Database error:', error);
      throw error;
    }
  }
};