import { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { setUsers, setLoading, setError } from '../store/slices/userSlice';
import { supabase } from '../lib/supabase';
import type { RootState } from '../store';

export function useUsers() {
  const dispatch = useDispatch();
  const { items: users, isLoading, error } = useSelector((state: RootState) => state.users);

  useEffect(() => {
    async function fetchUsers() {
      try {
        dispatch(setLoading(true));
        const { data, error } = await supabase
          .from('users')
          .select('*')
          .order('created_at', { ascending: false });

        if (error) throw error;
        dispatch(setUsers(data || []));
      } catch (err: any) {
        dispatch(setError(err.message));
      } finally {
        dispatch(setLoading(false));
      }
    }

    fetchUsers();
  }, [dispatch]);

  return { users, isLoading, error };
}